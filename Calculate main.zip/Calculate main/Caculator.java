 class Caculator{
    public static int plus(int a,int b){
       return (a+b);
    }
    public static int min(int a,int b){
        return (a-b);
    }
    public static double multi(double a,double b){
        return (a*b);
    }
    public static double div(double a,double b){
        return (a/b);
    }
}
