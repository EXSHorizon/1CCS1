public class Main{
    public static void main(String[] args){
      System.out.println(Caculator.plus(25,10));
      System.out.println(Caculator.min(15,8));
      System.out.println(Caculator.multi(8,5));
      System.out.println(Caculator.div(15,2));
    }
}